"""
dummy module.
"""

class QuantumClientException:
    pass

